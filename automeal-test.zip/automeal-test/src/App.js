import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import 'font-awesome/css/font-awesome.css';

import './global.css';

import Landing from './components/page/Landing';
import Survey from './components/page/Survey';
import Plan from './components/page/Plan';
import HP from './components/page/HP';
import Register from './components/page/Register';
import Footer from './components/shared/Footer';
import Login from './components/page/Login';
import Pantry from './components/page/Pantry';

class App extends Component {
  render() {
    return (
      <div>
        <Route exact path="/" component={Landing} />
        <Route path ="/register" component = {Register} />
        <Route path = "/login" component = {Login} />
        <Route path="/survey" component={Survey} />
        <Route path="/meal-plan" component={Plan} />
        <Route path="/home-page" component = {HP} />
        <Route path ="/pantry" component = {Pantry} />
        <Footer />
      </div>
    );
  }
}

export default App;
