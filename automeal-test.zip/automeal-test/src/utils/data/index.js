import  { Survey, API } from './data';

const getSurveyData = () => Survey ;
const getAPIData = () => API;

export{
  getSurveyData,
  getAPIData,
}
