import React from 'react';
import Button from '../Button';
import './Nav.css';

const Nav = () => (
  <div className="Nav">
    <Button className="Nav__button" link={true} path="/home-page" type="transparent">Home</Button>
    <Button className="Nav__button" link={true} path="/meal-plan" type="transparent">Meal Plan</Button>
    <Button className="Nav__button" link={true} path="/pantry" type="transparent">Pantry</Button>
  </div>
);

export default Nav;
