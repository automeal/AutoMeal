import React from 'react';
import './Footer.css';

const Footer = () => (
  <div className="Footer">
    <p>
      AutoMeal Meal Plan Generator
    </p>
  </div>
);

export default Footer;
