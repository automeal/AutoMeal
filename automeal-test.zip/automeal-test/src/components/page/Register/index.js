import React from 'react';
//import './Landing.css';
import Button from '../../shared/Button';

const Register = (props) => (
  <div className="Register">
    <div className="Register__banner">
    </div>
    <div className="Register__data">
      <div className="Register__data__content">
        <h1>AutoMeal Custom Meal Plan Generator</h1>
        <ul>
          <li>Build a Customizable Meal Plan Based On Your Preferences</li>
          <li>Track Calorie Intake and Nutrition Information</li>
          <li>Explore and Search New Recipes</li>
          <li>Organize Your Meals Around Your Pantry Items</li>
        </ul>
        <div><Button type="accent" link={true} path="/survey" className="Register__data__button">Begin Survey</Button></div>
      </div>
    </div>
  </div>
);

export default Register;