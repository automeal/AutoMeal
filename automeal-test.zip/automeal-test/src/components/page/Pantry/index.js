import Nav from '../../shared/Nav';
import React from 'react';
//import './Landing.css';


const Pantry = (props) => (
  <div className="Login">
  <Nav />
    <div className="Login__banner">
    </div>
    <div className="Login__data">
      <div className="Login__data__content">
        <h1>Pantry</h1>
        <ul>
          <li>User Selects Pantry Items</li>
          <li>Add and delete food items</li>
          <li>Send data to help generate meal plan based on items user has</li>
          <li>More front end than back end</li>
        </ul>
      </div>
    </div>
  </div>
);
export default Pantry;

/*import { Redirect } from 'react-router'

import Select from '../../shared/Form/Select';
import { CheckboxGroup } from '../../shared/Form/Checkbox';
import RadioGroup, { Radio } from '../../shared/Form/Radio';
import Button from '../../shared/Button';
import Tabs, { Tab } from '../../shared/Tabs';
import Nav from '../../shared/Nav';
//api related
import getPlan from '../../../utils/mealPlan';
import { getSurveyData } from '../../../utils/data';
*/