import React from 'react';
//import './Landing.css';
import Button from '../../shared/Button';

const Login = (props) => (
  <div className="Login">
    <div className="Login__banner">
    </div>
    <div className="Login__data">
      <div className="Login__data__content">
        <h1>Login Page</h1>
        <ul>
          <li>Username goes here</li>
          <li>Password</li>
          <li>Center it and create border</li>
          <li>Fix Buttons</li>
        </ul>
        <div><Button type="accent" link={true} path="/home-page" className="Login__data__button">Login</Button></div>
      </div>
    </div>
  </div>
);

export default Login;

/*import React from 'react';
import Button from '../../shared/Button';
import { FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import "./Login.css";

class Login extends React {
  constructor(props) {
    super(props);

    this.state = {
      email: "",
      password: ""
    };
  }

  validateForm() {
    return this.state.email.length > 0 && this.state.password.length > 0;
  }

  handleChange = event => {
    this.setState({
      [event.target.id]: event.target.value
    });
  };

  handleSubmit = async event => {
    event.preventDefault();

    try {
      console.log(this.state.email, this.state.password);
      alert("Logged in");
    } catch (e) {
      alert(e.message);
    }
  };

  render() {
    return (
      <div className="Login">
        <form onSubmit={this.handleSubmit}>
          <FormGroup controlId="email" bsSize="large">
            <ControlLabel>Email</ControlLabel>
            <FormControl
              autoFocus
              type="email"
              value={this.state.email}
              onChange={this.handleChange}
            />
          </FormGroup>
          <FormGroup controlId="password" bsSize="large">
            <ControlLabel>Password</ControlLabel>
            <FormControl
              value={this.state.password}
              onChange={this.handleChange}
              type="password"
            />
          </FormGroup>
          <Button
            block
            bsSize="large"
            disabled={!this.validateForm()}
            type="submit"
          >
            Login
          </Button>
        </form>
      </div>
    );
  }
}

export default Login;
*/